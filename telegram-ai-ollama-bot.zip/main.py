import os
import asyncio
from telethon import TelegramClient, events
import requests
from dotenv import load_dotenv

load_dotenv()

API_ID = int(os.getenv("API_ID"))
API_HASH = os.getenv("API_HASH")
SESSION_NAME = os.getenv("SESSION_NAME", "ollama_bot_session")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3")
OLLAMA_URL = "http://localhost:11434/api/generate"

client = TelegramClient(SESSION_NAME, API_ID, API_HASH)

def generate_reply(prompt):
    response = requests.post(OLLAMA_URL, json={
        "model": OLLAMA_MODEL,
        "prompt": prompt,
        "stream": False
    })
    if response.status_code == 200:
        return response.json().get("response", "...")
    return "Error: Unable to generate response."

@client.on(events.NewMessage(incoming=True))
async def handler(event):
    sender = await event.get_sender()
    message = event.raw_text
    if sender and message:
        reply = generate_reply(message)
        await event.reply(reply)

def main():
    print("Starting Telegram AI Auto-Reply Bot with Ollama...")
    with client:
        client.run_until_disconnected()

if __name__ == "__main__":
    main()
